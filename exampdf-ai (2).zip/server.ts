import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize Gemini
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY!,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

app.use(express.json({ limit: '50mb' }));

// API Routes
app.post("/api/extract-questions", async (req, res) => {
  try {
    const { pdfBase64, fileName } = req.body;
    
    if (!pdfBase64) {
      return res.status(400).json({ error: "No PDF data provided" });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          inlineData: {
            mimeType: "application/pdf",
            data: pdfBase64
          }
        },
        {
          text: `Extract all multiple choice questions (MCQs) from this exam PDF.
          
          FORMATTING RULES:
          1. Strictly use options A, B, C, D in this order for every question.
          2. The 'question' text must be clearly formatted. Use new lines for different parts (Assertion, Reason, Statements).
          3. Statements like (A), (B), (C) within a question MUST each be on a new line.
          4. If a question contains a diagram or image, represent it in the text as "(Diagram - name/description)".
          5. For each question, provide: question text, options A-D, subject (Physics, Chemistry, or Biology), difficulty, correct answer, and a short explanation.
          
          The output must be a JSON object with a 'questions' array.`
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  options: {
                    type: Type.OBJECT,
                    properties: {
                      A: { type: Type.STRING },
                      B: { type: Type.STRING },
                      C: { type: Type.STRING },
                      D: { type: Type.STRING }
                    },
                    required: ["A", "B", "C", "D"]
                  },
                  correctAnswer: { type: Type.STRING, enum: ["A", "B", "C", "D"] },
                  subject: { type: Type.STRING, enum: ["Physics", "Chemistry", "Biology", "General"] },
                  difficulty: { type: Type.STRING, enum: ["Easy", "Medium", "Hard"] },
                  solution: { type: Type.STRING, nullable: true },
                  type: { type: Type.STRING }
                },
                required: ["question", "options", "subject", "difficulty"]
              }
            }
          },
          required: ["questions"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    const result = JSON.parse(text);
    res.json(result);
  } catch (error: any) {
    console.error("Extraction error:", error);
    res.status(500).json({ error: error.message });
  }
});


async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
