import { useState, useEffect } from 'react';
import { auth, signInWithGoogle } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Dashboard } from './components/Dashboard';
import { UploadView } from './components/UploadView';
import { TestView } from './components/TestView';
import { ReportView } from './components/ReportView';
import { Test, TestAttempt } from './types';
import { motion, AnimatePresence } from 'framer-motion';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'home' | 'dashboard' | 'upload' | 'test' | 'report'>('home');
  const [currentTest, setCurrentTest] = useState<Test | null>(null);
  const [currentAttempt, setCurrentAttempt] = useState<TestAttempt | null>(null);
  const [testMode, setTestMode] = useState<'practice' | 'exam'>('practice');
  const [testDuration, setTestDuration] = useState<number>(180);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u && view === 'home') {
        setView('dashboard');
      }
    });
    return () => unsubscribe();
  }, [view]);

  const handleStartTest = (test: Test, mode: 'practice' | 'exam', duration?: number) => {
    setCurrentTest(test);
    setTestMode(mode);
    if (duration) setTestDuration(duration);
    setView('test');
  };

  const handleTestComplete = (attempt: TestAttempt) => {
    setCurrentAttempt(attempt);
    setView('report');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050608] text-gray-200 font-sans">
      <Navbar user={user} onSignIn={signInWithGoogle} onGoHome={() => setView(user ? 'dashboard' : 'home')} />
      
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mt-20"
            >
              <Hero onGetStarted={signInWithGoogle} />
            </motion.div>
          )}

          {view === 'dashboard' && user && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              <Dashboard 
                user={user} 
                onUploadClick={() => setView('upload')} 
                onStartTest={handleStartTest}
              />
            </motion.div>
          )}

          {view === 'upload' && user && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <UploadView 
                user={user} 
                onBack={() => setView('dashboard')} 
                onSuccess={(test) => {
                  setView('dashboard');
                }}
              />
            </motion.div>
          )}

          {view === 'test' && currentTest && user && (
            <motion.div
              key="test"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <TestView 
                test={currentTest} 
                mode={testMode} 
                duration={testDuration}
                user={user}
                onComplete={handleTestComplete}
                onCancel={() => setView('dashboard')}
              />
            </motion.div>
          )}

          {view === 'report' && currentAttempt && currentTest && (
            <motion.div
              key="report"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <ReportView 
                attempt={currentAttempt} 
                test={currentTest}
                onBack={() => setView('dashboard')} 
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

