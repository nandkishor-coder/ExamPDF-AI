import React, { useState, useEffect, MouseEvent } from 'react';
import { User } from 'firebase/auth';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { Test } from '../types';
import { Plus, BookOpen, Clock, Trash2, Box, ChevronRight, PlayCircle, Trophy, X, Settings2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface DashboardProps {
  user: User;
  onUploadClick: () => void;
  onStartTest: (test: Test, mode: 'practice' | 'exam', duration?: number) => void;
}

export function Dashboard({ user, onUploadClick, onStartTest }: DashboardProps) {
  const [tests, setTests] = useState<Test[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDurationModal, setShowDurationModal] = useState<Test | null>(null);
  const [customDuration, setCustomDuration] = useState(180);

  useEffect(() => {
    const q = query(
      collection(db, 'tests'),
      where('ownerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Test));
      setTests(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user.uid]);

  const handleDelete = async (testId: string, e: MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this test?')) {
      try {
        await deleteDoc(doc(db, 'tests', testId));
      } catch (error) {
        console.error("Error deleting test:", error);
      }
    }
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight">My Tests</h2>
          <p className="text-gray-500 mt-1 text-xs font-medium">View and practice your uploaded papers</p>
        </div>
        <button
          onClick={onUploadClick}
          className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl font-bold transition-all flex items-center gap-2 group shadow-lg shadow-blue-500/20"
        >
          <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform" />
          Upload New Paper
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 rounded-2xl bg-[#0a0c12] animate-pulse border border-gray-800" />
          ))}
        </div>
      ) : tests.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tests.map((test) => (
            <motion.div
              key={test.id}
              layout
              className="group p-6 rounded-2xl bg-[#0a0c12] border border-gray-800 hover:border-blue-500/50 transition-all shadow-xl hover:shadow-blue-500/5"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="p-3 bg-gray-900 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <Box className="w-6 h-6 text-blue-500 group-hover:text-white" />
                </div>
                <button
                  onClick={(e) => handleDelete(test.id, e)}
                  className="p-2 text-gray-600 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>

              <h3 className="text-lg font-bold text-white mb-2 line-clamp-1">{test.title}</h3>
              <p className="text-gray-500 text-xs mb-6 font-medium">
                {test.questions.length} Questions • {test.fileName}
              </p>

              <div className="flex items-center gap-4 mb-8">
                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-gray-500 bg-gray-900 px-3 py-1.5 rounded-lg border border-gray-800">
                  <BookOpen className="w-3 h-3" />
                  MCQ
                </div>
                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-gray-500 bg-gray-900 px-3 py-1.5 rounded-lg border border-gray-800">
                  <Clock className="w-3 h-3" />
                  180 Mins
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => onStartTest(test, 'practice')}
                  className="flex items-center justify-center gap-2 py-3 bg-gray-900 hover:bg-gray-800 text-gray-300 rounded-xl font-bold text-xs transition-colors border border-gray-800"
                >
                  <PlayCircle className="w-4 h-4" />
                  Practice
                </button>
                <button
                  onClick={() => setShowDurationModal(test)}
                  className="flex items-center justify-center gap-2 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs transition-colors shadow-lg shadow-blue-500/20"
                >
                  <Trophy className="w-4 h-4" />
                  Start Exam
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-20 bg-[#0a0c12]/30 rounded-2xl border border-dashed border-gray-800 text-center">
          <div className="w-20 h-20 bg-gray-900 rounded-full flex items-center justify-center mb-6">
            <Box className="w-10 h-10 text-gray-700" />
          </div>
          <h3 className="text-xl font-bold text-white">No tests yet</h3>
          <p className="text-gray-500 mt-2 mb-8 max-w-sm text-sm">
            Upload a PDF to get started with your first practice test.
          </p>
          <button
            onClick={onUploadClick}
            className="px-10 py-3 bg-gray-900 text-white rounded-xl border border-gray-800 hover:border-gray-700 transition-all font-bold"
          >
            Upload PDF
          </button>
        </div>
      )}

      {/* Duration Selection Modal */}
      <AnimatePresence>
        {showDurationModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDurationModal(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-md bg-[#0a0c12] border border-gray-800 rounded-2xl p-8 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-6">
                <div className="p-3 bg-blue-600/10 rounded-xl">
                  <Settings2 className="w-6 h-6 text-blue-500" />
                </div>
                <button 
                  onClick={() => setShowDurationModal(null)}
                  className="p-2 text-gray-500 hover:text-white transition-colors"
                >
                  <X />
                </button>
              </div>

              <h2 className="text-2xl font-bold text-white mb-2">Exam Duration</h2>
              <p className="text-gray-500 text-sm mb-8 leading-relaxed">
                Set how long you want to attempt this paper. Default is 180 minutes.
              </p>

              <div className="space-y-6 mb-10">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Time Duration</span>
                  <span className="text-2xl font-black text-white tracking-tighter">{customDuration} <span className="text-xs text-gray-500">min</span></span>
                </div>
                <input 
                  type="range" 
                  min="10" 
                  max="300" 
                  step="10"
                  value={customDuration}
                  onChange={(e) => setCustomDuration(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-900 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <div className="grid grid-cols-4 gap-2">
                  {[60, 120, 180, 240].map(m => (
                    <button
                      key={m}
                      onClick={() => setCustomDuration(m)}
                      className={`py-2 text-[10px] font-black rounded-lg border transition-all ${
                        customDuration === m 
                          ? 'border-blue-600 bg-blue-600/10 text-blue-500' 
                          : 'border-gray-800 bg-gray-900 text-gray-500 hover:border-gray-700'
                      }`}
                    >
                      {m}m
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  onStartTest(showDurationModal, 'exam', customDuration);
                  setShowDurationModal(null);
                }}
                className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all shadow-xl shadow-blue-500/20"
              >
                Launch Exam Environment
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
