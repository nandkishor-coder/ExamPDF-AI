import { User, signOut } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { BookOpen, LogOut, User as UserIcon, Shield } from 'lucide-react';
import { cn } from '../lib/utils';

interface NavbarProps {
  user: User | null;
  onSignIn: () => void;
  onGoHome: () => void;
}

export function Navbar({ user, onSignIn, onGoHome }: NavbarProps) {
  return (
    <nav className="border-b border-gray-800 bg-[#0a0c12] sticky top-0 z-50">
      <div className="container mx-auto px-6 h-16 flex items-center justify-between max-w-7xl">
        <div 
          className="flex items-center gap-3 cursor-pointer group" 
          onClick={onGoHome}
        >
          <div className="bg-blue-600 p-1.5 rounded-lg group-hover:bg-blue-500 transition-colors">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-black text-white leading-tight">
              ExamPDF <span className="text-blue-500">AI</span>
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-6">
          {user ? (
            <div className="flex items-center gap-6">
              <div className="hidden sm:flex flex-col items-end mr-2">
                <span className="text-sm font-bold text-white truncate max-w-[150px]">{user.displayName}</span>
                <span className="text-[10px] text-gray-500 uppercase">Student</span>
              </div>
              <div className="relative group">
                {user.photoURL ? (
                  <img 
                    src={user.photoURL} 
                    alt={user.displayName || 'User'} 
                    className="w-10 h-10 rounded-full border-2 border-slate-700 group-hover:border-blue-500 transition-colors"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center border-2 border-slate-700">
                    <UserIcon className="w-5 h-5 text-slate-400" />
                  </div>
                )}
                
                <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-1 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all transform origin-top-right scale-95 group-hover:scale-100">
                  <button 
                    onClick={() => signOut(auth)}
                    className="w-full flex items-center gap-2 px-4 py-2 text-sm text-slate-300 hover:bg-slate-800 hover:text-white rounded-lg transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <button 
              onClick={onSignIn}
              className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-xl font-medium transition-all transform active:scale-95 shadow-lg shadow-blue-500/20"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </nav>
  );
}
