import { useState, useCallback } from 'react';
import { useDropzone, DropzoneOptions } from 'react-dropzone';
import { User } from 'firebase/auth';
import { db, auth } from '../lib/firebase';
import { collection, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { FileUp, FileText, CheckCircle2, Loader2, X, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Test } from '../types';

interface UploadViewProps {
  user: User;
  onBack: () => void;
  onSuccess: (test: Test) => void;
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export function UploadView({ user, onBack, onSuccess }: UploadViewProps) {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'reading' | 'extracting' | 'saving' | 'done' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles[0]) {
      setFile(acceptedFiles[0]);
      setStatus('idle');
      setError(null);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    multiple: false,
  } as any);

  const handleUpload = async () => {
    if (!file) return;

    try {
      setUploading(true);
      setStatus('reading');
      
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = () => {
          const base64 = (reader.result as string).split(',')[1];
          resolve(base64);
        };
      });
      reader.readAsDataURL(file);
      const pdfBase64 = await base64Promise;

      setStatus('extracting');
      const response = await fetch('/api/extract-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pdfBase64, fileName: file.name }),
      });

      if (!response.ok) {
        throw new Error('Could not read the PDF. Please check if the file is correct.');
      }

      const result = await response.json();
      
      if (!result.questions || !Array.isArray(result.questions)) {
        throw new Error('AI could not find questions in this PDF.');
      }

      setStatus('saving');
      const testId = doc(collection(db, 'tests')).id;
      const testData = {
        id: testId,
        title: file.name.replace('.pdf', ''),
        description: `Test from ${file.name}`,
        ownerId: user.uid,
        questions: result.questions,
        createdAt: serverTimestamp(),
        status: 'completed',
        fileName: file.name,
      };

      try {
        await setDoc(doc(db, 'tests', testId), testData);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `tests/${testId}`);
      }
      
      setStatus('done');
      setTimeout(() => {
        onSuccess({ ...testData, createdAt: new Date() } as any);
      }, 1500);
    } catch (err: any) {
      console.error(err);
      try {
        const parsedError = JSON.parse(err.message);
        setError(parsedError.error || 'Permission denied. Please try again.');
      } catch {
        setError(err.message || 'Something went wrong. Please try again.');
      }
      setStatus('error');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight">Upload PDF</h2>
          <p className="text-gray-500 text-xs font-medium mt-1">Convert your paper into a practice test</p>
        </div>
        <button 
          onClick={onBack}
          className="text-gray-500 hover:text-white transition-colors text-sm font-bold uppercase tracking-wider"
        >
          Cancel
        </button>
      </div>

      <div className="bg-[#0a0c12] border border-gray-800 rounded-2xl overflow-hidden shadow-2xl">
        <div className="p-8">
          <AnimatePresence mode="wait">
            {!file ? (
              <motion.div
                key="dropzone"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                {...getRootProps()}
                className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all ${
                  isDragActive ? 'border-blue-500 bg-blue-500/5' : 'border-gray-800 hover:border-blue-500/50 bg-[#050608]/50'
                }`}
              >
                <input {...getInputProps()} />
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 bg-gray-900 rounded-xl flex items-center justify-center mb-6">
                    <FileUp className="w-10 h-10 text-gray-600" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">Drop your PDF here</h3>
                  <p className="text-gray-500 max-w-sm mx-auto text-sm leading-relaxed">
                    Select the PDF of your question paper. We will automatically extract all questions and options.
                  </p>
                  <div className="mt-10 px-8 py-3 bg-gray-900 hover:bg-gray-800 text-gray-300 rounded-xl transition-all border border-gray-800 font-bold text-sm">
                    Choose File
                  </div>
                </div>
              </motion.div>
            ) : status === 'done' ? (
              <motion.div
                key="done"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <div className="w-20 h-20 bg-blue-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 className="w-10 h-10 text-blue-500" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Upload Successful!</h3>
                <p className="text-gray-500 mb-8 max-w-sm mx-auto">Your paper has been processed. Redirecting to your test...</p>
              </motion.div>
            ) : (
              <motion.div
                key="uploading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-8"
              >
                <div className="flex items-center gap-4 p-5 bg-[#050608] rounded-xl border border-gray-800">
                  <div className="p-3 bg-blue-600/10 rounded-lg">
                    <FileText className="w-6 h-6 text-blue-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-white truncate text-sm">{file.name}</h3>
                    <p className="text-[10px] text-gray-600 font-bold">{(file.size / (1024 * 1024)).toFixed(2)} MB • Ready to start</p>
                  </div>
                  {!uploading && (
                    <button 
                      onClick={() => setFile(null)}
                      className="p-2 text-gray-600 hover:text-white transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  )}
                </div>

                {uploading && (
                  <div className="space-y-5">
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-500 font-medium lowercase">
                        {status === 'reading' && 'reading file...'}
                        {status === 'extracting' && 'AI is finding questions...'}
                        {status === 'saving' && 'saving your test...'}
                      </span>
                      <span className="text-blue-500 font-bold flex items-center gap-2">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        Processing
                      </span>
                    </div>
                    <div className="h-1.5 bg-gray-900 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-blue-600 shadow-[0_0_20px_rgba(37,99,235,0.4)]"
                        initial={{ width: "0%" }}
                        animate={{ 
                          width: status === 'reading' ? '33%' : status === 'extracting' ? '66%' : '90%' 
                        }}
                      />
                    </div>
                  </div>
                )}

                {error && (
                  <div className="flex items-start gap-4 p-4 bg-red-950/20 border border-red-900/30 rounded-xl text-red-500">
                    <AlertCircle className="w-5 h-5 mt-0.5" />
                    <div className="text-xs">
                      <p className="font-bold mb-1 uppercase tracking-widest text-[10px]">Error</p>
                      <p className="text-red-400/80 leading-relaxed font-medium">{error}</p>
                    </div>
                  </div>
                )}

                {!uploading && !error && (
                  <button
                    onClick={handleUpload}
                    className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all shadow-xl shadow-blue-500/20"
                  >
                    Start AI Extraction
                  </button>
                )}
                
                {error && (
                  <button
                    onClick={() => { setStatus('idle'); setError(null); handleUpload(); }}
                    className="w-full py-4 bg-gray-900 hover:bg-gray-800 text-white rounded-xl font-bold transition-all border border-gray-800"
                  >
                    Try Again
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
      
      <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-4 bg-[#0a0c12]/30 border border-gray-800/50 rounded-xl text-center">
          <div className="text-green-500 text-xs font-bold mb-1 uppercase tracking-wider">Accurate</div>
          <div className="text-gray-400 text-[10px]">99% accuracy in MCQ detection</div>
        </div>
        <div className="p-4 bg-[#0a0c12]/30 border border-gray-800/50 rounded-xl text-center">
          <div className="text-blue-500 text-xs font-bold mb-1 uppercase tracking-wider">Fast</div>
          <div className="text-gray-400 text-[10px]">Process any PDF in seconds</div>
        </div>
        <div className="p-4 bg-[#0a0c12]/30 border border-gray-800/50 rounded-xl text-center">
          <div className="text-purple-500 text-xs font-bold mb-1 uppercase tracking-wider">Smart</div>
          <div className="text-gray-400 text-[10px]">Detects Subjects & Chapters</div>
        </div>
      </div>
    </div>
  );
}

