import { useState, useEffect, useRef } from 'react';
import { User } from 'firebase/auth';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { Test, Question, TestAttempt, Subject } from '../types';
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  HelpCircle,
  Trophy,
  ArrowRight,
  Menu,
  X,
  FastForward,
  Flag
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../lib/utils';

interface TestViewProps {
  test: Test;
  mode: 'practice' | 'exam';
  duration: number;
  user: User;
  onComplete: (attempt: TestAttempt) => void;
  onCancel: () => void;
}

export function TestView({ test, mode, duration, user, onComplete, onCancel }: TestViewProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>(() => {
    const saved = localStorage.getItem(`test-answers-${test.id}`);
    return saved ? JSON.parse(saved) : {};
  });
  const [visited, setVisited] = useState<Set<number>>(() => {
    const saved = localStorage.getItem(`test-visited-${test.id}`);
    return saved ? new Set(JSON.parse(saved)) : new Set([0]);
  });
  const [timeLeft, setTimeLeft] = useState(duration * 60);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);
  const timerRef = useRef<any>(null);

  const currentQuestion = test.questions[currentIndex];

  useEffect(() => {
    localStorage.setItem(`test-answers-${test.id}`, JSON.stringify(answers));
  }, [answers, test.id]);

  useEffect(() => {
    localStorage.setItem(`test-visited-${test.id}`, JSON.stringify(Array.from(visited)));
  }, [visited, test.id]);

  useEffect(() => {
    setVisited(prev => new Set(prev).add(currentIndex));
  }, [currentIndex]);

  useEffect(() => {
    if (mode === 'exam') {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            handleSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [mode]);

  const handleSelectOption = (option: string) => {
    if (mode === 'practice' && answers[currentIndex]) return; // In practice, once answered it's locked to show feedback
    setAnswers(prev => ({ ...prev, [currentIndex]: option }));
  };

  const formatTime = (seconds: number) => {
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    return `${min}:${sec.toString().padStart(2, '0')}`;
  };

  const sortedOptions = Object.entries(currentQuestion.options).sort((a, b) => a[0].localeCompare(b[0]));

  const handleSubmit = async () => {
    localStorage.removeItem(`test-answers-${test.id}`);
    localStorage.removeItem(`test-visited-${test.id}`);

    const totalQuestions = test.questions.length;
    let correctCount = 0;
    let wrongCount = 0;
    let skippedCount = 0;
    
    const subjectAnalysis: Record<Subject, { total: number; correct: number; wrong: number }> = {
      'Physics': { total: 0, correct: 0, wrong: 0 },
      'Chemistry': { total: 0, correct: 0, wrong: 0 },
      'Biology': { total: 0, correct: 0, wrong: 0 },
      'General': { total: 0, correct: 0, wrong: 0 },
    };

    test.questions.forEach((q, idx) => {
      const userAnswer = answers[idx];
      const subject = q.subject || 'General';
      
      subjectAnalysis[subject].total++;

      if (!userAnswer) {
        skippedCount++;
      } else if (userAnswer === q.correctAnswer) {
        correctCount++;
        subjectAnalysis[subject].correct++;
      } else {
        wrongCount++;
        subjectAnalysis[subject].wrong++;
      }
    });

    // Score calculation (NEET/JEE style: +4 for correct, -1 for wrong)
    const score = (correctCount * 4) - wrongCount;
    const accuracy = totalQuestions > 0 ? (correctCount / (correctCount + wrongCount)) * 100 : 0;
    const timeSpent = (duration * 60) - timeLeft;

    const attempt: TestAttempt = {
      id: '', // Will be assigned by Firestore
      testId: test.id,
      userId: user.uid,
      score,
      totalQuestions,
      correctCount,
      wrongCount,
      skippedCount,
      accuracy,
      timeSpent,
      answers,
      completedAt: serverTimestamp(),
      subjectAnalysis,
    };

    try {
      const docRef = await addDoc(collection(db, 'results'), attempt);
      attempt.id = docRef.id;
      onComplete(attempt);
    } catch (error) {
      console.error("Error saving attempt:", error);
      // Still show the result even if save fails
      onComplete({ ...attempt, id: 'temp-' + Date.now() });
    }
  };

  return (
    <div className="fixed inset-0 bg-[#050608] flex flex-col z-[100] text-gray-200">
      {/* Header */}
      <header className="h-16 border-b border-gray-800 bg-[#0a0c12] flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center gap-4">
          <button 
            onClick={onCancel}
            className="p-2 hover:bg-gray-800 rounded-lg text-gray-500 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-white leading-tight">{test.title}</h1>
            <div className="flex items-center gap-2">
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">
                {mode === 'exam' ? 'Mock Test' : 'Practice Mode'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-8">
          {mode === 'exam' && (
            <div className="flex items-center bg-gray-900 px-4 py-2 rounded-full border border-gray-800">
              <span className="text-[10px] text-gray-400 mr-2 uppercase">Time Left:</span>
              <span className={cn(
                "text-xl font-mono font-bold tracking-tighter",
                timeLeft < 300 ? "text-red-500" : "text-blue-400"
              )}>
                {formatTime(timeLeft)}
              </span>
            </div>
          )}
          <div className="flex gap-2">
            <button 
              onClick={() => setShowConfirmSubmit(true)}
              className="px-4 py-2 text-xs bg-red-900/30 text-red-500 border border-red-800/50 rounded hover:bg-red-900/50 transition-colors"
            >
              Submit Test
            </button>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className={cn(
              "p-2 rounded-lg transition-colors",
              isSidebarOpen ? "bg-slate-800 text-white" : "hover:bg-slate-800 text-slate-400"
            )}
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>

      <main className="flex-1 flex flex-row overflow-hidden">
        <div className="flex-1 flex flex-col bg-[#050608] border-r border-gray-800 overflow-hidden">
          {/* Subject Selection Bar */}
          <div className="flex border-b border-gray-800 bg-[#0a0c12]/50 shrink-0">
            {['Physics', 'Chemistry', 'Biology'].map(sub => (
              <button 
                key={sub}
                className={cn(
                  "px-8 py-3 text-sm font-medium transition-all border-b-2",
                  currentQuestion.subject === sub 
                    ? "border-blue-500 bg-blue-500/10 text-blue-400" 
                    : "border-transparent text-gray-500 hover:text-gray-300"
                )}
              >
                {sub}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto p-8 md:p-12 custom-scrollbar">
            <div className="max-w-3xl mx-auto">
              {/* Question Card */}
              <div className="space-y-8">
                <div className="flex items-center space-x-3 mb-6">
                  <span className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-md text-xs font-bold border border-blue-600/30">
                    Q. {currentIndex + 1}
                  </span>
                  <span className="text-xs text-gray-500">
                    Single Correct | +4 / -1
                  </span>
                </div>

                <h2 className="text-xl md:text-2xl leading-relaxed text-white font-bold mb-8 whitespace-pre-wrap">
                  {currentQuestion.question}
                </h2>

                <div className="h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent w-full mb-12" />

                <div className="grid grid-cols-1 gap-5">
                  {sortedOptions.map(([key, value]) => (
                    <button
                      key={key}
                      onClick={() => handleSelectOption(key)}
                      className={cn(
                        "flex items-start p-5 rounded-2xl border transition-all text-left group relative overflow-hidden",
                        answers[currentIndex] === key 
                          ? mode === 'practice'
                            ? key === currentQuestion.correctAnswer
                              ? "bg-green-600/10 border-green-500 shadow-[0_0_20px_rgba(34,197,94,0.1)]"
                              : "bg-red-600/10 border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.1)]"
                            : "bg-blue-600/10 border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.1)]"
                          : mode === 'practice' && answers[currentIndex] && key === currentQuestion.correctAnswer
                            ? "bg-green-600/10 border-green-500"
                            : "bg-gray-900/40 border-gray-800 hover:border-gray-700 hover:bg-gray-800/40"
                      )}
                    >
                      <div className={cn(
                        "w-10 h-10 flex items-center justify-center rounded-xl mr-5 font-black shrink-0 transition-all shadow-sm",
                        answers[currentIndex] === key
                          ? mode === 'practice'
                            ? key === currentQuestion.correctAnswer
                              ? "bg-green-600 text-white"
                              : "bg-red-600 text-white"
                            : "bg-blue-600 text-white"
                          : mode === 'practice' && answers[currentIndex] && key === currentQuestion.correctAnswer
                            ? "bg-green-600 text-white"
                            : "bg-gray-800 text-gray-500 group-hover:bg-gray-700 group-hover:text-gray-300"
                      )}>
                        {key}
                      </div>
                      <div className="flex-1 py-1">
                        <p className={cn(
                          "text-base md:text-lg leading-relaxed whitespace-pre-wrap",
                          answers[currentIndex] === key ? "text-blue-50 font-semibold" : "text-gray-300"
                        )}>
                          {value}
                        </p>
                      </div>
                      {answers[currentIndex] === key && (
                        <div className={cn(
                          "absolute right-6 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full flex items-center justify-center",
                          mode === 'practice'
                            ? key === currentQuestion.correctAnswer ? "bg-green-600" : "bg-red-600"
                            : "bg-blue-600"
                        )}>
                          {mode === 'practice' && key !== currentQuestion.correctAnswer ? (
                            <X className="w-4 h-4 text-white" />
                          ) : (
                            <CheckCircle2 className="w-4 h-4 text-white" />
                          )}
                        </div>
                      )}
                    </button>
                  ))}
                </div>

                {mode === 'practice' && answers[currentIndex] && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-6 bg-gray-900/30 border border-gray-800 rounded-xl space-y-3"
                  >
                    <div className="flex items-center gap-2 text-blue-400 font-bold text-sm uppercase tracking-widest">
                      <HelpCircle className="w-4 h-4" />
                      Answer & Solution
                    </div>
                    <div className="text-gray-300 leading-relaxed text-sm">
                      <span className="font-bold text-green-500 mr-2">Correct Answer: {currentQuestion.correctAnswer}</span>
                      <p className="mt-2">{currentQuestion.solution}</p>
                    </div>
                  </motion.div>
                )}
              </div>
            </div>
          </div>

          {/* Action Buttons Footer */}
          <div className="px-8 py-4 bg-[#0a0c12]/80 backdrop-blur-md border-t border-gray-800 flex items-center justify-between gap-6 shrink-0 relative z-10">
            <div className="flex gap-2">
              <button
                onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
                disabled={currentIndex === 0}
                className="h-10 px-5 bg-gray-800 hover:bg-gray-700 text-[11px] font-black text-gray-400 rounded-xl border border-gray-700 transition-all disabled:opacity-10 flex items-center gap-2 uppercase tracking-tighter"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                Previous
              </button>
              <button
                onClick={() => setAnswers(prev => {
                  const n = { ...prev };
                  delete n[currentIndex];
                  return n;
                })}
                className="h-10 px-5 bg-gray-900/50 hover:bg-gray-800 text-[11px] font-black text-gray-600 rounded-xl border border-gray-800 transition-all uppercase tracking-tighter hover:text-gray-400"
              >
                Clear Response
              </button>
            </div>
            <button
              onClick={() => setCurrentIndex(prev => Math.min(test.questions.length - 1, prev + 1))}
              disabled={currentIndex === test.questions.length - 1}
              className="px-8 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-[11px] font-black rounded-xl shadow-lg shadow-blue-600/20 transition-all flex items-center justify-center gap-3 uppercase tracking-[0.1em] group relative overflow-hidden"
            >
              <span className="relative z-10">Save & Next Question</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform relative z-10" />
              <motion.div 
                className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity"
                initial={false}
              />
            </button>
          </div>
        </div>

        {/* Right Section: Sidebar / Palette */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.aside
              initial={{ x: 300 }}
              animate={{ x: 0 }}
              exit={{ x: 300 }}
              className="w-80 bg-[#0a0c12] flex flex-col shrink-0 border-l border-gray-800"
            >
              {/* User Profile Widget */}
              <div className="p-4 flex items-center space-x-4 border-b border-gray-800 bg-gray-900/20">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 border border-blue-400 flex items-center justify-center text-white font-bold uppercase">
                  {user.displayName?.split(' ').map(n => n[0]).join('') || 'U'}
                </div>
                <div className="flex-1 overflow-hidden">
                  <p className="text-sm font-bold truncate text-white">{user.displayName}</p>
                  <p className="text-[10px] text-gray-500 uppercase tracking-tighter">Student</p>
                </div>
              </div>

              {/* Question Grid Palette */}
              <div className="p-6 flex-1 overflow-y-auto custom-scrollbar">
                <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-6 flex items-center">
                  <span className="mr-3">Questions</span>
                  <div className="h-[1px] flex-1 bg-gray-800"></div>
                </h3>
                
                <div className="grid grid-cols-5 gap-2.5 mb-8">
                  {test.questions.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentIndex(i)}
                      className={cn(
                        "w-10 h-10 flex items-center justify-center rounded text-xs font-bold transition-all",
                         currentIndex === i 
                          ? "border-2 border-blue-500 bg-gray-800 text-white ring-2 ring-blue-500/20" 
                          : "",
                        answers[i] 
                          ? mode === 'practice'
                            ? answers[i] === test.questions[i].correctAnswer
                              ? "bg-green-600 text-white"
                              : "bg-red-600 text-white"
                            : "bg-green-600 text-white"
                          : visited.has(i)
                            ? "bg-gray-600/50 text-white"
                            : "bg-gray-900 text-gray-700 border border-gray-800 hover:border-gray-700 hover:text-gray-400"
                      )}
                    >
                      {(i + 1).toString().padStart(2, '0')}
                    </button>
                  ))}
                </div>

                <div className="space-y-4 border-t border-gray-800 pt-6">
                  <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">Legend</h3>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-3">
                    <div className="flex items-center text-[10px] text-gray-400">
                      <span className="w-3 h-3 bg-green-600 rounded mr-2"></span> Answered
                    </div>
                    <div className="flex items-center text-[10px] text-gray-400">
                      <span className="w-3 h-3 bg-red-600 rounded mr-2"></span> Wrong (Practice)
                    </div>
                    <div className="flex items-center text-[10px] text-gray-400">
                      <span className="w-3 h-3 bg-gray-600/50 rounded mr-2"></span> Visited
                    </div>
                    <div className="flex items-center text-[10px] text-gray-400">
                      <span className="w-3 h-3 bg-gray-900 border border-gray-800 rounded mr-2"></span> Not Visited
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats Widget */}
              <div className="p-6 bg-gray-900/40 border-t border-gray-800 mt-auto">
                <div className="flex justify-between items-end mb-4">
                  <div>
                    <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Your Progress</p>
                    <p className="text-xl font-bold text-white">
                      {Object.keys(answers).length}/{test.questions.length} 
                      <span className="text-xs text-gray-500 ml-1">Solved</span>
                    </p>
                  </div>
                  <div className="text-right text-blue-400 text-xs font-bold">
                    {Math.round((Object.keys(answers).length / test.questions.length) * 100)}% Done
                  </div>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-1.5 overflow-hidden">
                  <div 
                    className="bg-blue-600 h-full transition-all duration-500"
                    style={{ width: `${(Object.keys(answers).length / test.questions.length) * 100}%` }}
                  ></div>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </main>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {showConfirmSubmit && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowConfirmSubmit(false)}
              className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" 
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl"
            >
              <div className="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center mb-6">
                <AlertCircle className="w-8 h-8 text-blue-500" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Submit Test?</h3>
              <p className="text-slate-400 mb-8">
                You have answered <span className="text-white font-bold">{Object.keys(answers).length}</span> out of <span className="text-white font-bold">{test.questions.length}</span> questions. 
              </p>
              <div className="flex flex-col gap-3">
                <button
                  onClick={handleSubmit}
                  className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold transition-all shadow-xl shadow-blue-600/20"
                >
                  Yes, Submit
                </button>
                <button
                  onClick={() => setShowConfirmSubmit(false)}
                  className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl font-bold transition-all"
                >
                  Go Back
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
