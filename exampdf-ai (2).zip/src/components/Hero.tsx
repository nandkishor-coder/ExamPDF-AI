import { motion } from 'framer-motion';
import { FileUp, Cpu, BarChart3, ShieldCheck, Zap, Sparkles } from 'lucide-react';

interface HeroProps {
  onGetStarted: () => void;
}

export function Hero({ onGetStarted }: HeroProps) {
  const features = [
    {
      icon: <Cpu className="w-6 h-6 text-blue-400" />,
      title: "AI Extraction",
      description: "Convert PDFs into structured MCQ questions automatically."
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-purple-400" />,
      title: "Smart Analytics",
      description: "Detailed performance reports and subject-wise analysis."
    },
    {
      icon: <Zap className="w-6 h-6 text-amber-400" />,
      title: "Practice Modes",
      description: "Real exam simulation with negative marking and timers."
    }
  ];

  return (
    <div className="flex flex-col items-center text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 mb-8"
      >
        <Sparkles className="w-4 h-4" />
        <span className="text-sm font-medium border-b border-blue-500/30 pb-0.5">Test Prep Platform</span>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-5xl md:text-7xl font-bold mb-6 text-white tracking-tight"
      >
        Master Any Exam with <br />
        <span className="text-blue-500">ExamPDF AI</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto"
      >
        Upload your PDF papers and turn them into practice tests instantly. 
        Works for NEET, JEE, and Board exams.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex flex-col sm:flex-row gap-4 mb-20"
      >
        <button
          onClick={onGetStarted}
          className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-lg transition-all shadow-lg shadow-blue-500/20 flex items-center gap-2"
        >
          <FileUp className="w-5 h-5" />
          Get Started for Free
        </button>
        <a 
          href="#features"
          className="px-8 py-4 bg-gray-900/50 hover:bg-gray-900 text-gray-300 border border-gray-800 rounded-xl font-bold text-lg transition-all"
        >
          View Demo
        </a>
      </motion.div>

      <div id="features" className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-5xl px-4">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 + index * 0.1 }}
            className="p-8 rounded-2xl bg-[#0a0c12] border border-gray-800 hover:border-gray-700 transition-all text-left group shadow-xl"
          >
            <div className="mb-6 p-4 bg-gray-900 rounded-xl w-fit group-hover:bg-blue-600/10 group-hover:text-blue-400 transition-colors">
              {feature.icon}
            </div>
            <h3 className="text-xl font-bold mb-3 text-white">{feature.title}</h3>
            <p className="text-gray-500 leading-relaxed text-sm">
              {feature.description}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
