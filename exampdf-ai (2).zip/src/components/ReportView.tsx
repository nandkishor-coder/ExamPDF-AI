import { useEffect, useState } from 'react';
import { TestAttempt, Test } from '../types';
import { 
  Trophy, 
  Target, 
  Clock, 
  BarChart3, 
  ChevronLeft, 
  CheckCircle2, 
  XCircle, 
  MinusCircle,
  TrendingUp,
  BrainCircuit,
  Zap,
  ArrowRight,
  Download,
  Loader2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from 'recharts';
import confetti from 'canvas-confetti';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface ReportViewProps {
  attempt: TestAttempt;
  test: Test;
  onBack: () => void;
}

export function ReportView({ attempt, test, onBack }: ReportViewProps) {
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    if (attempt.accuracy > 70) {
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#3b82f6', '#22c55e', '#ffffff']
      });
    }
  }, [attempt.accuracy]);

  const COLORS = ['#22c55e', '#ef4444', '#64748b'];
  const pieData = [
    { name: 'Correct', value: attempt.correctCount },
    { name: 'Wrong', value: attempt.wrongCount },
    { name: 'Skipped', value: attempt.skippedCount },
  ];

  const subjectData = Object.entries(attempt.subjectAnalysis)
    .filter(([_, data]) => data.total > 0)
    .map(([subject, data]) => ({
      subject,
      correct: data.correct,
      wrong: data.wrong,
      total: data.total,
      accuracy: Math.round((data.correct / data.total) * 100)
    }));

  const formatTime = (seconds: number) => {
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    return `${min}m ${sec}s`;
  };

  const handleDownloadPDF = async () => {
    try {
      setDownloading(true);
      const element = document.getElementById('report-content');
      if (!element) return;

      // Temporary styles to ensure clean capture
      const originalStyle = element.style.cssText;
      element.style.padding = '40px';
      element.style.background = '#050608';

      const canvas = await html2canvas(element, {
        scale: 1.5, // Reduced scale for better performance on large content
        backgroundColor: '#050608',
        useCORS: true,
        logging: false,
        windowWidth: 1200, // Fixed width for consistent layout
        width: element.scrollWidth,
        height: element.scrollHeight
      });
      
      element.style.cssText = originalStyle;

      const imgData = canvas.toDataURL('image/png', 0.8);
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: [canvas.width, canvas.height]
      });

      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height, undefined, 'FAST');
      pdf.save(`Report_${test.title.replace(/\s+/g, '_')}.pdf`);
    } catch (error) {
      console.error('PDF Generation failed:', error);
      alert('PDF generation failed. Please try using "Ctrl + P" and select "Save as PDF" for a better result.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-20 p-4 sm:p-0">
      <div className="flex items-center justify-between">
        <button 
          onClick={onBack}
          className="flex items-center gap-3 text-gray-500 hover:text-white transition-colors group text-sm font-bold"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Dashboard
        </button>
        <div className="flex items-center gap-6">
          <button
            onClick={handleDownloadPDF}
            disabled={downloading}
            className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg text-xs font-bold transition-all border border-gray-700 disabled:opacity-50"
          >
            {downloading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                Preparing PDF...
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                Download PDF
              </>
            )}
          </button>
          <div className="text-right">
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">ID</p>
            <p className="text-white font-mono text-xs">{attempt.id.slice(0, 8)}</p>
          </div>
        </div>
      </div>

      <div id="report-content" className="space-y-10 bg-[#050608]">

      {/* Header section */}
      <div className="relative overflow-hidden p-8 md:p-12 rounded-2xl bg-[#0a0c12] border border-gray-800 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/5 blur-[120px] rounded-full" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-600/5 blur-[120px] rounded-full" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-12">
          <div className="flex flex-col items-center text-center">
            <div className="relative mb-8">
              <div className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-gray-800 flex items-center justify-center bg-[#050608] shadow-[0_0_50px_rgba(59,130,246,0.1)]">
                <span className="text-4xl md:text-5xl font-black text-white tracking-tighter">{attempt.score}</span>
              </div>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-blue-600 text-[10px] uppercase tracking-widest px-4 py-1.5 rounded-full font-black text-white whitespace-nowrap">
                YOUR SCORE
              </div>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2 tracking-tight">{test.title}</h2>
            <p className="text-gray-500 text-xs font-bold uppercase tracking-widest">TEST RESULTS</p>
          </div>

          <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full">
            <div className="p-6 bg-[#050608] rounded-xl border border-gray-800">
              <div className="flex items-center gap-3 text-blue-500 mb-4 opacity-50">
                <Target className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Accuracy</span>
              </div>
              <p className="text-3xl font-black text-white tracking-tighter">{Math.round(attempt.accuracy)}%</p>
            </div>
            
            <div className="p-6 bg-[#050608] rounded-xl border border-gray-800">
              <div className="flex items-center gap-3 text-blue-500 mb-4 opacity-50">
                <Clock className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Time Taken</span>
              </div>
              <p className="text-3xl font-black text-white tracking-tighter">{formatTime(attempt.timeSpent)}</p>
            </div>

            <div className="p-6 bg-[#050608] rounded-xl border border-gray-800">
              <div className="flex items-center gap-3 text-blue-500 mb-4 opacity-50">
                <TrendingUp className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Correct</span>
              </div>
              <p className="text-3xl font-black text-white tracking-tighter">{attempt.correctCount}</p>
            </div>

            <div className="p-6 bg-[#050608] rounded-xl border border-gray-800">
              <div className="flex items-center gap-3 text-blue-500 mb-4 opacity-50">
                <BrainCircuit className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Strongest</span>
              </div>
              <p className="text-lg font-black text-white truncate tracking-tight">
                {subjectData.sort((a, b) => b.accuracy - a.accuracy)[0]?.subject || 'N/A'}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="p-8 rounded-2xl bg-[#0a0c12] border border-gray-800">
            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-10 flex items-center gap-3">
              <BarChart3 className="w-4 h-4 text-blue-500" />
              Subject Performance
              <div className="h-[1px] flex-1 bg-gray-900"></div>
            </h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={subjectData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#161b22" vertical={false} />
                  <XAxis dataKey="subject" stroke="#484f58" fontSize={10} tickLine={false} axisLine={false} fontWeight="bold" />
                  <YAxis stroke="#484f58" fontSize={10} tickLine={false} axisLine={false} fontWeight="bold" />
                  <Tooltip 
                    cursor={{ fill: '#0d1117' }}
                    contentStyle={{ backgroundColor: '#0a0c12', border: '1px solid #30363d', borderRadius: '12px' }}
                  />
                  <Bar dataKey="correct" name="Correct" fill="#238636" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="wrong" name="Wrong" fill="#da3633" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-xl bg-[#0a0c12] border border-gray-800 text-center">
              <h4 className="text-gray-500 font-bold text-[10px] uppercase tracking-widest mb-2">Correct</h4>
              <p className="text-3xl font-black text-green-500 tracking-tighter">{attempt.correctCount}</p>
            </div>
            <div className="p-6 rounded-xl bg-[#0a0c12] border border-gray-800 text-center">
              <h4 className="text-gray-500 font-bold text-[10px] uppercase tracking-widest mb-2">Wrong</h4>
              <p className="text-3xl font-black text-red-500 tracking-tighter">{attempt.wrongCount}</p>
            </div>
            <div className="p-6 rounded-xl bg-[#0a0c12] border border-gray-800 text-center">
              <h4 className="text-gray-500 font-bold text-[10px] uppercase tracking-widest mb-2">Skipped</h4>
              <p className="text-3xl font-black text-gray-500 tracking-tighter">{attempt.skippedCount}</p>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="p-8 rounded-2xl bg-[#0a0c12] border border-gray-800 flex flex-col h-full shadow-2xl">
            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-10 flex items-center gap-3">
              Overall Result
              <div className="h-[1px] flex-1 bg-gray-900"></div>
            </h3>
            <div className="h-64 mb-8">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={85}
                    paddingAngle={8}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-5 mb-12">
              {pieData.map((entry, index) => (
                <div key={entry.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: COLORS[index] }} />
                    <span className="text-xs text-gray-500 font-bold uppercase tracking-wider">{entry.name}</span>
                  </div>
                  <span className="text-white font-black text-lg tracking-tighter">{entry.value}</span>
                </div>
              ))}
            </div>

            <div className="mt-auto p-6 bg-blue-600/5 border border-blue-600/10 rounded-xl">
              <h4 className="text-blue-500 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 mb-3">
                <Zap className="w-3.5 h-3.5" />
                AI Suggestion
              </h4>
              <p className="text-xs text-gray-400 leading-relaxed font-medium">
                {attempt.accuracy < 50 
                  ? "Focus on the basics. Try solving easier questions first to build confidence."
                  : attempt.accuracy < 80
                  ? "Good job! Review your weak areas to improve your score further."
                  : "Excellent! You are performing at a very high level. Keep it up!"}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div className="flex flex-col sm:flex-row justify-center gap-4 pt-8">
        <button
          onClick={handleDownloadPDF}
          disabled={downloading}
          className="px-8 py-4 bg-gray-800 hover:bg-gray-700 text-white rounded-xl font-bold text-sm transition-all border border-gray-700 flex items-center justify-center gap-3 uppercase tracking-widest disabled:opacity-50 shadow-xl"
        >
          {downloading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Download className="w-5 h-5" />
          )}
          Download Report
        </button>
        <button
          onClick={onBack}
          className="group px-12 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-sm transition-all shadow-xl shadow-blue-500/20 flex items-center justify-center gap-4 uppercase tracking-widest"
        >
          Back to Dashboard
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
}
