export type Subject = 'Physics' | 'Chemistry' | 'Biology' | 'General';
export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export interface Question {
  question: string;
  options: {
    A: string;
    B: string;
    C: string;
    D: string;
  };
  correctAnswer: 'A' | 'B' | 'C' | 'D' | null;
  subject: Subject;
  difficulty: Difficulty;
  solution: string | null;
  type: string;
}

export interface Test {
  id: string;
  title: string;
  description: string;
  ownerId: string;
  questions: Question[];
  createdAt: any; // ServerTimestamp
  status: 'processing' | 'completed' | 'failed';
  fileName: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  createdAt: any;
}

export interface TestAttempt {
  id: string;
  testId: string;
  userId: string;
  score: number;
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  skippedCount: number;
  accuracy: number;
  timeSpent: number; // in seconds
  answers: Record<number, string>; // question index -> answer
  completedAt: any;
  subjectAnalysis: Record<Subject, {
    total: number;
    correct: number;
    wrong: number;
  }>;
}
